# Ide ke Video Gratis Studio V3.0

Aplikasi lokal berbasis Flask untuk membuat video faceless edukasi finansial. Tidak memerlukan API key atau langganan AI.

## Fitur
- Generator ide dan naskah template lokal: Personal Finance, Psikologi Uang, Investasi Dasar, Crypto, Trading & Risk.
- Editor judul dan teks setiap adegan serta narasi voice-over.
- Visual finansial dibuat otomatis dengan Pillow: panel grafik, grid, aksen warna, judul, teks pendukung, dan progress scene.
- Animasi kamera zoom perlahan (Ken Burns) menggunakan FFmpeg.
- Voice-over sintetis lokal melalui eSpeak NG (offline, gratis; kualitas suara cenderung robotik).
- Musik ambient orisinal dibuat secara prosedural; bukan lagu komersial.
- Ekspor MP4 16:9 (1280x720), 9:16 (720x1280), dan 1:1 (900x900).
- Thumbnail JPG otomatis dari scene pembuka, deskripsi, dan hashtag YouTube.

## Jalankan di GitHub Codespaces

Cara termudah: buka repository di Codespaces, lalu pilih **Rebuild Container** agar `.devcontainer/devcontainer.json` memasang FFmpeg dan eSpeak NG otomatis.

Jika container sudah berjalan, jalankan di terminal:

```bash
sudo apt-get update
sudo apt-get install -y ffmpeg espeak-ng fonts-dejavu-core
python -m pip install -r requirements.txt
python app.py
```

Buka tab **Ports**, lalu klik port `5000`.

## Jalankan di komputer Linux

```bash
sudo apt-get update
sudo apt-get install -y ffmpeg espeak-ng fonts-dejavu-core
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Di Windows, instal FFmpeg dan eSpeak NG lalu pastikan executable tersedia di PATH sebelum menjalankan `python app.py`.

## Alur penggunaan
1. Pilih kategori dan masukkan judul (atau kosongkan untuk ide otomatis).
2. Pilih durasi naskah dan gaya narasi, lalu klik **Buat ide & naskah**.
3. Edit judul, narasi, dan isi setiap scene.
4. Pilih rasio video, lama tiap scene, bahasa voice-over, serta audio.
5. Klik **Render video MP4** dan tunggu proses selesai.
6. Unduh hasil dari tombol Download MP4.

## Catatan batasan yang perlu diketahui
- Generator ide/naskah menggunakan template lokal, bukan model AI generatif.
- Visual merupakan ilustrasi grafik/infografik yang digambar otomatis, bukan stok footage, foto realistis, avatar, atau video generatif.
- eSpeak NG menghasilkan suara sintetis yang dapat terdengar robotik. Ini adalah TTS offline gratis, bukan suara manusia natural.
- Durasi video akhir dapat dipilih 30 detik sampai 10 menit dan dibagi otomatis ke seluruh scene. Untuk video panjang, proses render membutuhkan waktu dan CPU lebih besar; durasi narasi TTS belum otomatis dipanjangkan agar tepat sama dengan durasi video.
- Musik latar merupakan ambient sederhana hasil sintesis audio lokal.
- Periksa fakta, risiko, dan klaim finansial sebelum mempublikasikan video. Materi bukan nasihat investasi.

## Troubleshooting
- `Could not open requirements file`: pastikan terminal berada di folder yang berisi `requirements.txt`. Jalankan `pwd` dan `ls -la`.
- `espeak-ng not found`: `sudo apt-get install -y espeak-ng`.
- `ffmpeg` error: pastikan paket FFmpeg terpasang dan jalankan `python -m pip install -r requirements.txt`.
- Render panjang memerlukan CPU dan ruang disk. Coba 3 detik per scene untuk tes awal.

## Pemeriksaan
Endpoint status: `http://localhost:5000/health`
