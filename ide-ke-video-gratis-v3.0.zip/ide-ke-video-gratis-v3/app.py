from flask import Flask, render_template, request, jsonify, send_file
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import os, re, json, math, wave, struct, subprocess, tempfile, shutil, uuid, random
from pathlib import Path
import imageio_ffmpeg

BASE = Path(__file__).resolve().parent
OUT = BASE / 'outputs'
OUT.mkdir(exist_ok=True)
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024

CATEGORIES = {
 'Personal Finance': {
  'ideas': ['3 kebiasaan kecil yang membuat keuangan lebih sehat','Cara membangun dana darurat dari nol','Kesalahan mengatur gaji yang sering tidak disadari','Metode sederhana membagi penghasilan bulanan'],
  'hook': 'Pernah merasa uang selalu habis padahal baru menerima gaji? Bisa jadi masalahnya bukan jumlah penghasilan, tetapi sistem yang kita gunakan.',
  'points': ['Catat seluruh pemasukan dan pengeluaran selama satu bulan.','Pisahkan kebutuhan, keinginan, tabungan, dan cicilan sejak awal menerima penghasilan.','Bangun dana darurat secara bertahap dan sesuaikan target dengan kondisi pribadi.','Evaluasi anggaran setiap minggu agar kebocoran kecil cepat terlihat.']},
 'Psikologi Uang': {
  'ideas': ['Mengapa kita sering belanja saat sedang stres?','Efek gaya hidup yang naik bersama penghasilan','Cara menghentikan keputusan impulsif','Mengapa membandingkan kekayaan bisa merusak keuangan'],
  'hook': 'Keputusan keuangan tidak selalu dibuat dengan logika. Emosi, kebiasaan, dan lingkungan sering ikut menentukan ke mana uang kita pergi.',
  'points': ['Kenali pemicu emosional sebelum melakukan pembelian.','Terapkan jeda 24 jam untuk barang yang tidak mendesak.','Tentukan tujuan keuangan yang terukur agar keputusan lebih terarah.','Kurangi paparan pemicu konsumsi dan bandingkan progres dengan diri sendiri.']},
 'Investasi Dasar': {
  'ideas': ['Memahami risiko dan imbal hasil sebelum berinvestasi','Apa itu diversifikasi dan mengapa penting?','Investasi rutin untuk pemula','Perbedaan menabung dan berinvestasi'],
  'hook': 'Investasi bukan sekadar mencari keuntungan besar. Hal pertama yang perlu dipahami justru risiko dan tujuan keuangan kita.',
  'points': ['Tentukan tujuan dan jangka waktu investasi.','Pahami potensi penurunan nilai sebelum membeli aset.','Sebarkan risiko sesuai kemampuan dan jangan menaruh semua dana pada satu instrumen.','Gunakan dana dingin dan evaluasi secara berkala, bukan karena panik sesaat.']},
 'Crypto': {
  'ideas': ['Memahami blockchain tanpa istilah rumit','Risiko menyimpan aset kripto di exchange','Apa itu volatilitas dalam pasar kripto?','Cara mengenali janji keuntungan kripto yang tidak masuk akal'],
  'hook': 'Harga aset kripto bisa bergerak sangat cepat. Sebelum ikut tren, pahami dulu teknologi, risiko, dan cara melindungi aset.',
  'points': ['Pelajari fungsi aset dan jaringan yang digunakan, bukan hanya pergerakan harganya.','Pahami volatilitas dan kemungkinan kehilangan sebagian besar modal.','Aktifkan keamanan akun berlapis dan waspadai tautan atau pesan palsu.','Hindari keputusan karena FOMO dan jangan gunakan uang kebutuhan pokok.']},
 'Trading & Risk': {
  'ideas': ['Mengapa stop loss penting dalam trading?','Memahami risk to reward ratio','Kesalahan overtrading yang menguras modal','Cara membuat jurnal trading sederhana'],
  'hook': 'Dalam trading, satu keuntungan besar tidak otomatis membuat strategi menjadi bagus. Yang lebih penting adalah bagaimana risiko dikendalikan.',
  'points': ['Tentukan batas risiko sebelum membuka posisi.','Gunakan stop loss sesuai rencana dan jangan menggesernya hanya karena berharap.','Hitung risk to reward agar potensi hasil sebanding dengan risiko.','Catat alasan masuk, keluar, dan emosi untuk mengevaluasi keputusan.']}
}

TITLES = ['Pahami Masalahnya','Langkah Praktis','Kesalahan yang Perlu Dihindari','Rangkuman dan Aksi']


def get_font(size, bold=False):
    candidates = ['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
                  '/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf']
    for p in candidates:
        if os.path.exists(p): return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def wrap_text(draw, text, font, max_width):
    words = text.split(); lines=[]; line=''
    for word in words:
        test = (line + ' ' + word).strip()
        if draw.textbbox((0,0), test, font=font)[2] <= max_width: line=test
        else:
            if line: lines.append(line)
            line=word
    if line: lines.append(line)
    return lines


def generate_script(category, topic, duration, tone):
    data=CATEGORIES.get(category, CATEGORIES['Personal Finance'])
    seconds=int(duration)
    count=max(3, min(18, math.ceil(seconds/35)))
    points=(data['points'] * ((count+len(data['points'])-1)//len(data['points'])))[:count]
    intro=data['hook']
    tone_intro={'edukatif':'Mari kita bahas dengan langkah sederhana dan contoh yang mudah diterapkan.',
                'storytelling':'Bayangkan kamu mengalami situasi ini: keputusan kecil hari ini ternyata memengaruhi kondisi keuangan beberapa bulan ke depan.',
                'tegas':'Jangan mengambil keputusan finansial hanya karena ikut-ikutan. Pahami alasannya terlebih dahulu.'}.get(tone, '')
    scenes=[('HOOK', intro), ('KONTEKS', tone_intro or 'Topik ini penting karena keputusan kecil yang dilakukan berulang dapat membentuk kondisi keuangan jangka panjang.')]
    for i,p in enumerate(points):
        if seconds <= 60:
            body=p
        elif seconds <= 180:
            body=p + ' Setelah itu, periksa apakah langkah tersebut sesuai dengan tujuan dan kemampuan keuanganmu. Lakukan secara konsisten dan evaluasi hasilnya.'
        else:
            body=(p + ' Mulailah dengan kondisi yang benar-benar kamu hadapi, bukan dengan asumsi atau mengikuti keputusan orang lain. '
                  'Pecah langkah ini menjadi tindakan kecil yang bisa dilakukan dan dicatat secara rutin. '
                  'Perhatikan biaya, risiko, dan konsekuensi sebelum mengambil keputusan. '
                  'Sebagai contoh, buat catatan sederhana tentang tujuan, batas kemampuan, dan hasil yang ingin dievaluasi. ' 
                  'Jika situasinya berubah, tinjau kembali rencana tanpa terburu-buru mengambil keputusan karena emosi. ' 
                  'Yang terpenting adalah konsistensi, pemahaman risiko, dan kesesuaian dengan kebutuhan pribadi.')
        scenes.append((TITLES[i%len(TITLES)], body))
    scenes.append(('PENUTUP', 'Mulailah dari satu langkah kecil hari ini. Sesuaikan keputusan dengan tujuan, kondisi, dan toleransi risiko masing-masing. Edukasi ini bersifat umum, bukan nasihat keuangan atau rekomendasi transaksi.'))
    narration=' '.join([f'{topic}.', intro, tone_intro] + [body for _,body in scenes[2:]] + ['Itulah pembahasan kali ini. Like, komentar, dan subscribe untuk edukasi finansial berikutnya.'])
    description=f'{topic}\n\nVideo edukasi tentang {category.lower()}. Materi ini bersifat informatif dan bukan rekomendasi investasi atau ajakan transaksi. Selalu lakukan riset mandiri dan sesuaikan keputusan dengan kondisi pribadi.'
    tags='#KeuanganPribadi #EdukasiFinansial #LiterasiKeuangan #Investasi #BelajarKeuangan'
    return {'topic':topic,'scenes':scenes,'narration':narration,'description':description,'tags':tags}


def draw_scene(size, category, topic, heading, body, idx, total, ratio):
    w,h=size
    im=Image.new('RGB',(w,h),(8,15,31)); px=im.load()
    # subtle diagonal blue/teal gradient
    for y in range(h):
        for x in range(w):
            t=(x/w*.55+y/h*.45)
            px[x,y]=(int(7+8*t),int(15+27*t),int(31+34*t))
    d=ImageDraw.Draw(im,'RGBA')
    # decorative glow and grid
    d.ellipse((int(w*.60),-int(h*.25),int(w*1.12),int(h*.45)),fill=(14,145,160,38))
    d.ellipse((-int(w*.2),int(h*.7),int(w*.35),int(h*1.2)),fill=(40,95,200,30))
    for x in range(0,w,80): d.line((x,0,x,h),fill=(100,160,200,15),width=1)
    for y in range(0,h,80): d.line((0,y,w,y),fill=(100,160,200,15),width=1)
    # chart panel with scene-specific bars and line
    panel=(int(w*.62),int(h*.20),int(w*.92),int(h*.76))
    d.rounded_rectangle(panel,radius=28,fill=(11,27,49,210),outline=(62,190,190,150),width=2)
    left,top,right,bottom=panel
    for j in range(5):
        yy=top+int((j+1)*(bottom-top)/6); d.line((left+20,yy,right-20,yy),fill=(130,180,210,35),width=1)
    vals=[.24,.42,.35,.58,.52,.77,.66,.88]
    pts=[]
    for j,v in enumerate(vals):
        xx=left+25+int(j*(right-left-50)/(len(vals)-1)); yy=bottom-30-int(v*(bottom-top-80))
        pts.append((xx,yy))
        bw=max(12,int((right-left-90)/len(vals)*.45))
        d.rounded_rectangle((xx-bw//2,yy,xx+bw//2,bottom-24),radius=5,fill=(32,170+int(40*v),165,100))
    d.line(pts,fill=(70,230,210,255),width=5)
    for x,y in pts: d.ellipse((x-6,y-6,x+6,y+6),fill=(235,255,250,255))
    # content block
    margin=int(w*.075); title_font=get_font(max(25,int(w*.045)),True); body_font=get_font(max(18,int(w*.026)))
    small=get_font(max(14,int(w*.017)),True)
    d.rounded_rectangle((margin,int(h*.12),margin+int(w*.14),int(h*.17)),radius=12,fill=(18,150,145,220))
    d.text((margin+14,int(h*.125)),category.upper()[:22],font=small,fill=(245,255,255,255))
    d.text((margin,int(h*.25)),heading.upper(),font=title_font,fill=(105,235,220,255))
    maxw=int(w*.49); lines=wrap_text(d,body,body_font,maxw)
    y=int(h*.36); line_h=int(body_font.size*1.45)
    for line in lines[:5]:
        d.text((margin,y),line,font=body_font,fill=(241,246,252,255)); y+=line_h
    # footer / progress
    d.text((margin,int(h*.88)),topic[:70],font=small,fill=(185,200,220,220))
    d.rounded_rectangle((margin,int(h*.94),w-margin,int(h*.955)),radius=8,fill=(70,90,115,130))
    d.rounded_rectangle((margin,int(h*.94),margin+int((w-2*margin)*(idx+1)/total),int(h*.955)),radius=8,fill=(53,220,190,240))
    return im


def make_voice(text, path, voice='id', speed=155):
    exe=shutil.which('espeak-ng') or shutil.which('espeak')
    if not exe: return False, 'espeak-ng belum terpasang. Jalankan: sudo apt-get install -y espeak-ng'
    voice_code='id' if voice=='id' else 'en-us'
    try:
        subprocess.run([exe,'-v',voice_code,'-s',str(speed),'-w',str(path),text[:12000]],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=240)
        return True, 'Voice-over dibuat dengan eSpeak NG (suara sintetis lokal).'
    except Exception as e: return False, f'Gagal membuat voice-over: {e}'


def make_music(path, seconds):
    # Original generated ambient bed; not a commercial music track.
    rate=22050; frames=int(rate*seconds); freqs=[110.0,164.81,220.0]
    with wave.open(str(path),'wb') as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(rate)
        chunk=4096
        for start in range(0,frames,chunk):
            data=[]
            for n in range(start,min(start+chunk,frames)):
                t=n/rate; fade=min(1,t/1.5,(seconds-t)/2 if seconds>2 else 1)
                v=sum(math.sin(2*math.pi*f*t)*.18 for f in freqs)/3
                v += .025*math.sin(2*math.pi*330*t)*math.sin(2*math.pi*.12*t)
                data.append(struct.pack('<h',int(max(-1,min(1,v*max(0,fade)))*32767)))
            wf.writeframes(b''.join(data))


def render_video(payload, ratio, target_seconds, voice_enabled, music_enabled, voice_lang, tone):
    if ratio=='9:16': size=(720,1280)
    elif ratio=='1:1': size=(900,900)
    else: size=(1280,720)
    job=uuid.uuid4().hex[:10]; work=OUT/job; work.mkdir(parents=True)
    scenes=payload['scenes']; ffmpeg=imageio_ffmpeg.get_ffmpeg_exe(); segments=[]
    fps=24; target_seconds=max(10,int(target_seconds)); base=target_seconds//len(scenes); remainder=target_seconds%len(scenes)
    scene_durations=[max(2,base+(1 if i<remainder else 0)) for i in range(len(scenes))]
    try:
        for i,(heading,body) in enumerate(scenes):
            dur=scene_durations[i]
            img=draw_scene(size,payload.get('category','Finance'),payload['topic'],heading,body,i,len(scenes),ratio)
            img_path=work/f'scene_{i:02d}.png'; img.save(img_path)
            seg=work/f'seg_{i:02d}.mp4'; segments.append(seg)
            # Slow Ken Burns movement; render each designed scene as animated video.
            vf=f"scale={size[0]}:{size[1]},zoompan=z='min(zoom+0.0008,1.045)':d={dur*fps}:s={size[0]}x{size[1]}:fps={fps},format=yuv420p"
            subprocess.run([ffmpeg,'-y','-loop','1','-i',str(img_path),'-t',str(dur),'-vf',vf,'-r',str(fps),'-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p',str(seg)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=180)
        concat=work/'concat.txt'
        concat.write_text('\n'.join("file '"+p.name+"'" for p in segments),encoding='utf-8')
        silent=work/'silent.mp4'
        subprocess.run([ffmpeg,'-y','-f','concat','-safe','0','-i',str(concat),'-c','copy',str(silent)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=180)
        final=OUT/f'{job}-video.mp4'; thumb=OUT/f'{job}-thumbnail.jpg'; audio_inputs=[]; voice_path=work/'voice.wav'; music_path=work/'music.wav'; notes=[]
        draw_scene((1280,720),payload.get('category','Finance'),payload['topic'],'VIDEO HIGHLIGHT',scenes[0][1],0,1,'16:9').save(thumb,quality=90)
        total=sum(scene_durations)
        if voice_enabled:
            ok,msg=make_voice(payload['narration'],voice_path,voice_lang)
            notes.append(msg)
            if ok: audio_inputs += ['-i',str(voice_path)]
        if music_enabled:
            make_music(music_path,total); audio_inputs += ['-i',str(music_path)]
        if audio_inputs:
            # Input 0 video, audio inputs start at 1. Mix available tracks.
            cmd=[ffmpeg,'-y','-i',str(silent)]
            cmd += audio_inputs
            if voice_enabled and voice_path.exists() and music_enabled:
                cmd += ['-filter_complex','[1:a]volume=1.0[v];[2:a]volume=0.16[m];[v][m]amix=inputs=2:duration=longest[a]','-map','0:v','-map','[a]']
            elif voice_enabled and voice_path.exists(): cmd += ['-map','0:v','-map','1:a','-af','apad']
            else: cmd += ['-filter:a','volume=0.18','-map','0:v','-map','1:a']
            cmd += ['-t',str(total),'-c:v','copy','-c:a','aac','-b:a','160k',str(final)]
            subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=240)
        else: shutil.copy2(silent,final)
        return final, {'notes':notes,'duration_seconds':total,'scenes':len(scenes),'resolution':f'{size[0]}x{size[1]}','thumbnail_url':f'/download/{thumb.name}','thumbnail_filename':thumb.name}
    except subprocess.CalledProcessError as e:
        err=e.stderr.decode('utf-8','ignore')[-1800:] if e.stderr else str(e)
        raise RuntimeError('FFmpeg gagal merender video: '+err)


@app.route('/')
def index(): return render_template('index.html', categories=list(CATEGORIES.keys()))

@app.route('/api/generate',methods=['POST'])
def api_generate():
    data=request.get_json(force=True); category=data.get('category','Personal Finance'); duration=data.get('duration','60')
    topic=(data.get('topic') or '').strip()
    if not topic:
        topic=random.choice(CATEGORIES.get(category,CATEGORIES['Personal Finance'])['ideas'])
    result=generate_script(category,topic,duration,data.get('tone','edukatif')); result['category']=category
    return jsonify(result)

@app.route('/api/render',methods=['POST'])
def api_render():
    data=request.get_json(force=True)
    try:
        scenes=[]
        for line in data.get('scenes',[]):
            if isinstance(line,dict) and line.get('heading') and line.get('body'): scenes.append((line['heading'][:80],line['body'][:500]))
        if not scenes: return jsonify({'error':'Naskah scene kosong. Buat atau isi naskah terlebih dahulu.'}),400
        payload={'topic':(data.get('topic') or 'Video Edukasi Finansial')[:120],'category':data.get('category','Personal Finance'),'scenes':scenes,'narration':(data.get('narration') or ' '.join(x[1] for x in scenes))[:12000]}
        final,meta=render_video(payload,data.get('ratio','16:9'),data.get('target_seconds',60),bool(data.get('voice')),bool(data.get('music')),data.get('voice_lang','id'),data.get('tone','edukatif'))
        return jsonify({'video_url':f'/download/{final.name}','filename':final.name,'meta':meta})
    except Exception as e: return jsonify({'error':str(e)}),500

@app.route('/download/<name>')
def download(name):
    path=OUT/name
    if not path.exists() or path.suffix.lower() not in ('.mp4','.jpg'): return 'File tidak ditemukan',404
    download_name='thumbnail-v3.jpg' if path.suffix.lower()=='.jpg' else 'video-faceless-v3.mp4'
    return send_file(path,as_attachment=True,download_name=download_name)

@app.route('/health')
def health():
    return jsonify({'status':'ok','version':'3.0','ffmpeg':bool(imageio_ffmpeg.get_ffmpeg_exe()),'espeak':bool(shutil.which('espeak-ng') or shutil.which('espeak'))})

if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)),debug=False)
