# Ide ke Video Gratis

Aplikasi web sederhana untuk membuat ide konten, naskah, lalu merender naskah menjadi video slideshow MP4.

## Fitur
- Generator ide berdasarkan kategori: personal finance, psikologi uang, crypto, trading & risk, investasi dasar.
- Generator hook, isi, dan penutup.
- Render MP4 720p dengan teks per-scene.
- Tidak membutuhkan API key, layanan berbayar, atau model AI eksternal.

> Catatan: generator ide/script pada versi ini memakai template lokal (bukan AI generatif). Video berupa slideshow teks tanpa voice-over, avatar, musik, atau footage. Ini menjaga versi awal tetap gratis dan mudah dijalankan.

## Jalankan di GitHub Codespaces
1. Buat repository GitHub baru, lalu upload seluruh isi folder ini.
2. Buka repository → **Code** → **Codespaces** → **Create codespace on main**.
3. Tunggu proses instalasi dependency selesai.
4. Buka Terminal dan jalankan:
   ```bash
   python app.py
   ```
5. Buka tab **Ports**, pastikan port `8000` berstatus **Forwarded**, lalu klik **Open in Browser**.
6. Pilih kategori, klik **Buat ide & script**, lalu klik **Render & unduh video MP4**.

## Jalankan di komputer
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Buka http://localhost:8000

## Struktur
```text
.
├── app.py
├── requirements.txt
├── templates/
│   └── index.html
├── static/
│   └── style.css
└── .devcontainer/
    └── devcontainer.json
```

## Pengembangan berikutnya
Versi berikutnya dapat menambahkan provider AI gratis berbasis kuota, text-to-speech, pilihan rasio 9:16/16:9, gambar latar, dan editor scene. API key sebaiknya disimpan sebagai Codespaces Secret atau environment variable, bukan ditulis di source code.
