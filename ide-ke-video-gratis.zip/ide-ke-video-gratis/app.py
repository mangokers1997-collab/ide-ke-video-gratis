from flask import Flask, render_template, request, send_file, flash, redirect, url_for
from PIL import Image, ImageDraw, ImageFont
import imageio_ffmpeg
import tempfile, os, textwrap, random, re

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "local-dev-key")

TOPICS = {
    "Personal Finance": [
        "5 kebiasaan kecil yang bikin uang cepat habis",
        "Cara membuat anggaran bulanan sederhana",
        "Dana darurat: mulai dari nominal kecil",
        "Kesalahan mengatur gaji pertama",
        "Bedakan kebutuhan dan keinginan"
    ],
    "Psikologi Uang": [
        "Kenapa kita sering belanja impulsif?",
        "Efek gaya hidup ikut-ikutan pada keuangan",
        "Cara membangun disiplin menabung",
        "Mengatasi FOMO saat melihat investasi orang lain"
    ],
    "Crypto": [
        "Apa itu Bitcoin untuk pemula?",
        "Blockchain dijelaskan dengan analogi sederhana",
        "Perbedaan coin dan token",
        "Cara mengenali penipuan kripto"
    ],
    "Trading & Risk": [
        "Apa arti risk/reward ratio?",
        "Mengapa stop loss itu penting?",
        "Jangan trading dengan uang kebutuhan",
        "Cara membuat jurnal trading sederhana"
    ],
    "Investasi Dasar": [
        "Apa itu diversifikasi?",
        "Investasi vs trading: apa bedanya?",
        "Mengenal risiko dan imbal hasil",
        "Mulai investasi dengan tujuan yang jelas"
    ]
}

HOOKS = [
    "Pernah merasa uang baru masuk, tapi tiba-tiba sudah habis?",
    "Banyak orang melakukan kesalahan ini tanpa menyadarinya.",
    "Sebelum mengambil keputusan, pahami satu hal penting ini.",
    "Kalau kamu baru mulai, simak sampai akhir."
]

def make_script(topic, audience, duration, tone):
    title = topic.strip() or "Cara mengelola uang dengan lebih bijak"
    hook = random.choice(HOOKS)
    seconds = int(duration)
    intro = f"{hook}\nHari ini kita bahas {title.lower()}."
    points = [
        f"Pertama, pahami kondisi dan tujuanmu. Jangan mengambil keputusan hanya karena ikut-ikutan.",
        f"Kedua, mulai dari langkah kecil yang realistis. Catat hasilnya dan evaluasi secara berkala.",
        f"Ketiga, kenali risikonya. Tidak ada strategi yang selalu berhasil, jadi siapkan batas yang sanggup kamu tanggung."
    ]
    body = "\n".join(f"{i+1}. {p}" for i,p in enumerate(points))
    outro = "Kesimpulannya, pahami dulu sebelum bertindak dan sesuaikan keputusan dengan kondisi masing-masing.\nJangan lupa like, komentar, dan subscribe untuk edukasi berikutnya."
    return {"title": title, "hook": intro, "body": body, "outro": outro,
            "full": f"{intro}\n\n{body}\n\n{outro}",
            "scenes": [intro] + points + [outro]}

def font(size, bold=False):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"
    ]
    for p in candidates:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()

def render_video(title, scenes, out_path):
    W, H, fps = 1280, 720, 24
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    cmd = [ffmpeg, "-y", "-f", "rawvideo", "-vcodec", "rawvideo", "-s", f"{W}x{H}",
           "-pix_fmt", "rgb24", "-r", str(fps), "-i", "-", "-an",
           "-vcodec", "libx264", "-pix_fmt", "yuv420p", "-movflags", "+faststart", out_path]
    import subprocess
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    try:
        for idx, text in enumerate(scenes):
            for frame in range(fps * 4):
                im = Image.new("RGB", (W,H))
                px = im.load()
                for y in range(H):
                    c = int(16 + 22*y/H)
                    for x in range(W):
                        px[x,y] = (c//2, c, min(80, c+35))
                d = ImageDraw.Draw(im)
                d.rounded_rectangle((70,55,W-70,H-55), radius=34, outline=(70,190,180), width=3)
                d.text((105,90), "IDE KE VIDEO • GRATIS", font=font(24, True), fill=(100,235,210))
                d.text((105,145), title[:65], font=font(30, True), fill="white")
                wrapped = textwrap.wrap(text, width=34)
                line_h = 58
                total_h = len(wrapped)*line_h
                y0 = (H-total_h)//2 + 25
                for line in wrapped[:7]:
                    bbox = d.textbbox((0,0), line, font=font(43, True))
                    d.text(((W-(bbox[2]-bbox[0]))//2, y0), line, font=font(43, True), fill=(255,255,255))
                    y0 += line_h
                d.text((105,H-105), f"SCENE {idx+1}/{len(scenes)}", font=font(22), fill=(160,205,205))
                proc.stdin.write(im.tobytes())
        proc.stdin.close()
        err = proc.stderr.read().decode("utf-8", "ignore")
        code = proc.wait()
        if code != 0:
            raise RuntimeError(err[-1200:])
    except Exception:
        proc.kill()
        raise

@app.route("/", methods=["GET","POST"])
def index():
    result = None
    category = "Personal Finance"
    if request.method == "POST":
        category = request.form.get("category", "Personal Finance")
        topic = request.form.get("topic", "").strip()
        if not topic:
            topic = random.choice(TOPICS.get(category, TOPICS["Personal Finance"]))
        result = make_script(topic, request.form.get("audience","Pemula"),
                             request.form.get("duration","60"), request.form.get("tone","Edukasi"))
    return render_template("index.html", topics=TOPICS, result=result, selected=category)

@app.route("/video", methods=["POST"])
def video():
    title = request.form.get("title","Video edukasi")
    raw = request.form.get("scenes","")
    scenes = [s.strip() for s in raw.split("\n---\n") if s.strip()]
    if not scenes:
        flash("Naskah kosong. Buat naskah terlebih dahulu.")
        return redirect(url_for("index"))
    tmp = tempfile.NamedTemporaryFile(suffix=".mp4", delete=False)
    tmp.close()
    try:
        render_video(title, scenes, tmp.name)
        return send_file(tmp.name, as_attachment=True, download_name="video-edukasi.mp4",
                         mimetype="video/mp4")
    except Exception as e:
        flash("Gagal membuat video: " + str(e))
        return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8000)), debug=True)
